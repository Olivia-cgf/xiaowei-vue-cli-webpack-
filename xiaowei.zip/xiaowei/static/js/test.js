function test() {
    console.log("jsdfal");
}
/*var test=function(){
      console.log("aaaa");
}()*/

(function showMsg(){console.log("这是自调用函数测试")})()


function showMsg() {
    console.log('ssssssss')
}

