window._bd_share_config = {
        common : {
            bdText : '自定义分享内容', 
            bdDesc : '自定义分享摘要', 
            bdUrl : '自定义分享url地址',   
            bdPic : 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1504516371570&di=fa187d2e2b2e8f968a46598311ea4221&imgtype=0&src=http%3A%2F%2Fwww.cnhubei.com%2Fxwzt%2F2015%2F2015snjlx%2Fsnjfj%2F201509%2FW020150930775925767248.jpg'
        },
        share : [{
            "bdSize" : 16
        }]
    }
    with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?cdnversion='+~(-new Date()/36e5)];