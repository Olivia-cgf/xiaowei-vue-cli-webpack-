<template>
  <div class="header">
      <!-- logo图标 -->
      <div class="logo">
          <img src="./img/logo.png" alt="">
      </div>

  </div>
</template>

<script type="text/ecmascript-6">
export default {

};
</script>

<style lang="stylus" rel="stylesheet/stylus">
.header
    width: 100px
    height: 100%
    float:left
    font-size: 14px
    color: #fff
    text-align: center
</style>
