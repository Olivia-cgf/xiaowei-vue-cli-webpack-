<template>
  <div class="login">
    <button id="qqLoginBtn" @click="te">sdfasd</button>
  </div>
</template>

<script type="text/javascript">
 export default {
  data () {
     return {
     };
  },
   mounted: function () {
       /* let url1 = 'http://lib.sinaapp.com/js/jquery/1.7.2/jquery.min.js';
        let script1 = document.createElement('script');
        script1.setAttribute('src', url1);
        document.getElementsByTagName('head')[0].appendChild(script1);
        let url2 = 'http://qzonestyle.gtimg.cn/qzone/openapi/qc_loader.js';
        let script2 = document.createElement('script');
        script2.setAttribute('src', url2);
        script2.setAttribute('data-appid', '101368749');
        script2.setAttribute('data-redirecturi', 'http://chengguifang.oicp.io:28670/');
        document.getElementsByTagName('head')[0].appendChild(script2);
        this.$nextTick(() => {
        //  window.onload = function () {
         QC.Login({
              btnId: 'qqLoginBtn'
           });
        //  };
         });
         var qqLogin = new qqLogin.QC('qqLoginBtn');
         qqLogin.Login({
              btnId: 'qqLoginBtn'
           }); */
    },
    methods: {
       te: function () {
         // showMsg();
         // test();
         // console.log('console.log');
       },
       showMsg () {
        // test();
       }
    }
 };
</script>
<style  lang="stylus" rel="stylesheet/stylus">

</style>
